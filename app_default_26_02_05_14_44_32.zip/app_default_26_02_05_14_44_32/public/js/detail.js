// Drama Detail Page Script

let currentDramaId = null;
let currentEpisodes = [];
let filteredEpisodes = [];

// Get Drama ID from URL
function getDramaIdFromURL() {
    const pathname = window.location.pathname;
    const match = pathname.match(/\/drama\/(\d+)/);
    return match ? parseInt(match[1]) : null;
}

// Initialize Detail Page
document.addEventListener('DOMContentLoaded', () => {
    currentDramaId = getDramaIdFromURL();
    
    if (!currentDramaId) {
        showError('ID Drama tidak valid');
        return;
    }
    
    loadDramaDetail();
    setupDetailEventListeners();
});

// Setup Event Listeners
function setupDetailEventListeners() {
    const filterBtn = document.getElementById('filterBtn');
    const clearFilterBtn = document.getElementById('clearFilterBtn');
    const episodeFilter = document.getElementById('episodeFilter');

    if (filterBtn) {
        filterBtn.addEventListener('click', filterEpisodes);
    }

    if (clearFilterBtn) {
        clearFilterBtn.addEventListener('click', () => {
            if (episodeFilter) {
                episodeFilter.value = '';
            }
            displayEpisodes(currentEpisodes);
        });
    }

    if (episodeFilter) {
        episodeFilter.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                filterEpisodes();
            }
        });
    }
}

// Load Drama Detail
async function loadDramaDetail() {
    try {
        const detailLoader = document.getElementById('dramaDetailLoader');
        showLoader(detailLoader);

        const response = await dramaAPI.getDetail(currentDramaId);
        
        if (response.success) {
            const { drama, episodes } = response.data;
            currentEpisodes = episodes || [];
            filteredEpisodes = [...currentEpisodes];
            
            displayDramaDetail(drama);
            displayEpisodes(currentEpisodes);
        } else {
            showError(response.message || 'Gagal memuat detail drama');
        }
    } catch (error) {
        const errorMessage = handleAPIError(error);
        showError(errorMessage);
    }
}

// Display Drama Detail
function displayDramaDetail(drama) {
    const detailLoader = document.getElementById('dramaDetailLoader');
    const dramaDetail = document.getElementById('dramaDetail');
    const errorState = document.getElementById('errorState');

    hideLoader(detailLoader);

    if (!drama || Object.keys(drama).length === 0) {
        if (dramaDetail) dramaDetail.style.display = 'none';
        if (errorState) errorState.style.display = 'block';
        return;
    }

    // Update page title
    document.title = `${drama.title || 'Drama'} - FlickReels`;

    // Populate drama info
    const poster = document.getElementById('dramaPoster');
    const title = document.getElementById('dramaTitle');
    const year = document.getElementById('dramaYear');
    const genre = document.getElementById('dramaGenre');
    const description = document.getElementById('dramaDescription');
    const status = document.getElementById('dramaStatus');
    const episodeCount = document.getElementById('episodeCount');

    if (poster) {
        poster.src = drama.poster_path || drama.poster || 'https://via.placeholder.com/250x350';
        poster.alt = drama.title || 'Poster';
        poster.onerror = () => {
            poster.src = 'https://via.placeholder.com/250x350?text=Error';
        };
    }

    if (title) title.textContent = drama.title || drama.name || 'Tanpa Judul';
    if (year) year.textContent = drama.year || drama.release_date?.split('-')[0] || 'N/A';
    if (genre) genre.textContent = drama.genre || drama.genres?.join(', ') || 'N/A';
    if (description) description.textContent = drama.description || drama.overview || 'Deskripsi tidak tersedia';
    if (status) status.textContent = drama.status || 'Ongoing';
    if (episodeCount) episodeCount.textContent = currentEpisodes.length || '0';

    if (dramaDetail) dramaDetail.style.display = 'block';
    if (errorState) errorState.style.display = 'none';
}

// Display Episodes
function displayEpisodes(episodes) {
    const episodesList = document.getElementById('episodesList');
    
    if (!episodesList) return;

    if (!episodes || episodes.length === 0) {
        episodesList.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--text-secondary);">
                <h3>📭 Tidak ada episode</h3>
            </div>
        `;
        return;
    }

    episodesList.innerHTML = episodes.map(episode => createEpisodeCard(episode)).join('');
}

// Create Episode Card
function createEpisodeCard(episode) {
    const episodeNum = episode.episode || episode.ep || episode.number || '?';
    const title = episode.title || episode.name || `Episode ${episodeNum}`;

    return `
        <div class="episode-card" onclick="playEpisode(${currentDramaId}, '${episodeNum}', '${title.replace(/'/g, "\\'")}')">
            <div class="episode-number">Ep ${episodeNum}</div>
            <div class="episode-title">${title}</div>
        </div>
    `;
}

// Filter Episodes
function filterEpisodes() {
    const episodeFilter = document.getElementById('episodeFilter');
    const filterValue = episodeFilter.value.trim();

    if (!filterValue) {
        displayEpisodes(currentEpisodes);
        return;
    }

    const episodeNum = parseInt(filterValue);
    if (isNaN(episodeNum)) {
        showError('Masukkan nomor episode yang valid');
        return;
    }

    const filtered = currentEpisodes.filter(ep => {
        const num = parseInt(ep.episode || ep.ep || ep.number || 0);
        return num === episodeNum;
    });

    if (filtered.length === 0) {
        document.getElementById('episodesList').innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--text-secondary);">
                <h3>❌ Episode tidak ditemukan</h3>
            </div>
        `;
    } else {
        displayEpisodes(filtered);
    }
}

// Show Error
function showError(message) {
    const detailLoader = document.getElementById('dramaDetailLoader');
    const dramaDetail = document.getElementById('dramaDetail');
    const errorState = document.getElementById('errorState');

    hideLoader(detailLoader);

    if (dramaDetail) dramaDetail.style.display = 'none';
    if (errorState) {
        errorState.style.display = 'block';
        document.getElementById('errorStateMessage').textContent = message;
    }
}

// Play Episode (placeholder - integrate with player)
function playEpisode(dramaId, episodeNum, title) {
    console.log(`Playing Drama ${dramaId}, Episode ${episodeNum}: ${title}`);
    showPlayerSection(episodeNum, title);
}

// Show Player Section
function showPlayerSection(episodeNum, title) {
    const playerSection = document.getElementById('playerSection');
    const playerTitle = document.getElementById('playerTitle');
    
    if (playerSection) {
        playerTitle.textContent = `Episode ${episodeNum} - ${title}`;
        playerSection.style.display = 'block';
        playerSection.scrollIntoView({ behavior: 'smooth' });
    }
}

// Close Player
function closePlayer() {
    const playerSection = document.getElementById('playerSection');
    if (playerSection) {
        playerSection.style.display = 'none';
    }
}
