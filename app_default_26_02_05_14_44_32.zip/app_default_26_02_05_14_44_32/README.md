# FlickReels - Website Drama Cina

Website streaming drama cina yang modern dan responsif dengan integrasi API FlickReels. Tampilkan drama trending, fitur pencarian, detail episode lengkap, dan video player yang mulus.

## ✨ Fitur Utama

- 🎬 **Tampilan Trending** - Menampilkan drama terpopuler
- 🔍 **Pencarian Drama** - Cari drama dengan pagination halaman (page=1, 2, 3, dst)
- 📺 **Detail Drama** - Lihat semua episode dan informasi lengkap drama
- ▶️ **Video Player** - Player video yang responsif dengan kontrol penuh
- 📱 **Responsive Design** - Sempurna di desktop, tablet, dan mobile
- ⚡ **Fast Loading** - API optimization dan error handling yang baik
- 🎨 **Modern UI** - Dark theme yang elegan dengan animasi smooth

## 📋 Persyaratan

- **Node.js** versi 14.x atau lebih tinggi
- **npm** versi 6.x atau lebih tinggi
- Browser modern (Chrome, Firefox, Safari, Edge)

## 🚀 Instalasi & Setup

### 1. Clone atau Download Project

