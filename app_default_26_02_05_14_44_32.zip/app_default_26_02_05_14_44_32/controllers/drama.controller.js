const apiClient = require('../utils/api-client');
const { formatResponse, formatPagination } = require('../utils/response-formatter');

exports.getLanguages = async (req, res, next) => {
  try {
    const response = await apiClient.get('/languages');
    res.json(formatResponse(true, 'Daftar bahasa berhasil diambil', response.data));
  } catch (error) {
    next(error);
  }
};

exports.getTrending = async (req, res, next) => {
  try {
    const { lang = 6 } = req.query;
    const response = await apiClient.get('/trending', {
      params: { lang }
    });
    
    const formattedData = {
      dramas: response.data.data || response.data || [],
      total: response.data.total || (response.data.data ? response.data.data.length : 0)
    };
    
    res.json(formatResponse(true, 'Drama trending berhasil diambil', formattedData));
  } catch (error) {
    next(error);
  }
};

exports.searchDramas = async (req, res, next) => {
  try {
    const { q, lang = 6, page = 1 } = req.query;
    
    if (!q || q.trim().length === 0) {
      return res.status(400).json(formatResponse(false, 'Query pencarian tidak boleh kosong'));
    }

    const response = await apiClient.get('/search', {
      params: { 
        q: q.trim(), 
        lang,
        page: parseInt(page)
      }
    });
    
    const dramas = response.data.data || response.data || [];
    const pagination = formatPagination(page, dramas.length);
    
    res.json(formatResponse(true, 'Pencarian drama berhasil', {
      dramas,
      pagination,
      query: q
    }));
  } catch (error) {
    next(error);
  }
};

exports.listDramas = async (req, res, next) => {
  try {
    const { lang = 6, page = 1 } = req.query;
    
    const response = await apiClient.get('/nexthome', {
      params: { 
        lang,
        page: parseInt(page)
      }
    });
    
    const dramas = response.data.data || response.data || [];
    const pagination = formatPagination(page, dramas.length);
    
    res.json(formatResponse(true, 'Daftar drama berhasil diambil', {
      dramas,
      pagination
    }));
  } catch (error) {
    next(error);
  }
};

exports.getDramaDetail = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { lang = 6 } = req.query;
    
    if (!id || isNaN(id)) {
      return res.status(400).json(formatResponse(false, 'ID drama tidak valid'));
    }

    const response = await apiClient.get(`/drama/${id}`, {
      params: { lang }
    });
    
    const drama = response.data.data || response.data || {};
    
    res.json(formatResponse(true, 'Detail drama berhasil diambil', {
      drama,
      episodes: drama.episodes || drama.data || []
    }));
  } catch (error) {
    next(error);
  }
};

module.exports = exports;
